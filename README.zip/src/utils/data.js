export const Data=[
    {
        title:'Live care',
        image:'https://media.istockphoto.com/id/1134451603/photo/she-knows-just-how-to-make-each-patient-feel-special.jpg?s=2048x2048&w=is&k=20&c=F1D3KYiQ0ZGEsVwN-6HKuviE5o-0bZA4j0T6LIrFIgM=',
        description:'Wellness hotels have been around for a while, but are now becoming a focal point for both business and leisure travelers. With good reason! Not only are wellness hotels often more in-tune with nature, but they’re also soothing for the mind, body, and soul.',
        price:'$100'
        
    },
    {
        title:'Surpportin live care',
        image:'https://images.pexels.com/photos/6782567/pexels-photo-6782567.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
        description:'Hotels are typically larger establishments that offer a range of amenities and facilities, such as restaurants, bars, conference rooms, and fitness centres. They often have multiple room options, including single rooms, double rooms, suites, and family rooms.',
        price:'$100'
    },
    {
        title:'Staffs to NHS Hospitals ',
        image:'https://images.pexels.com/photos/8442574/pexels-photo-8442574.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
        description:'Doctors assess and manage your medical treatment. Nurses provide ongoing care. Allied health professionals provide services to help with diagnosis and treatment, and help you during the recovery process. Support and administrative staff work to support the day-to-day running of the hospital.',
        price:'$100'
    },
    {
        title:'Nursing and care homes ',
        image:'https://media.istockphoto.com/id/1134451603/photo/she-knows-just-how-to-make-each-patient-feel-special.jpg?s=2048x2048&w=is&k=20&c=F1D3KYiQ0ZGEsVwN-6HKuviE5o-0bZA4j0T6LIrFIgM=',
        description:'Nursing homes care for people who struggle significantly with daily life or have various medical conditions and need regular treatment from registered nurses. Nurses are supported by qualified care assistants, trained to identify symptoms and changes to residents.',
        price:'$100'
    },
    {
        title:'Private Hospitals ',
        image:'https://images.pexels.com/photos/668300/pexels-photo-668300.jpeg?auto=compress&cs=tinysrgb&w=600',
        description:'Doctors assess and manage your medical treatment. Nurses provide ongoing care. Allied health professionals provide services to help with diagnosis and treatment, and help you during the recovery process. Support and administrative staff work to support the day-to-day running of the hospital.',
        price:'$100'
    },
    {
        title:'Live care Hotels',
        image:'https://media.istockphoto.com/id/1134451603/photo/she-knows-just-how-to-make-each-patient-feel-special.jpg?s=2048x2048&w=is&k=20&c=F1D3KYiQ0ZGEsVwN-6HKuviE5o-0bZA4j0T6LIrFIgM=',
        description:'Wellness hotels have been around for a while, but are now becoming a focal point for both business and leisure travelers. With good reason! Not only are wellness hotels often more in-tune with nature, but they’re also soothing for the mind, body, and soul. ',
        price:'$100'
        
    },
    {
        title:'Private Hospitals ',
        image:'https://images.pexels.com/photos/668300/pexels-photo-668300.jpeg?auto=compress&cs=tinysrgb&w=600',
        description:'Doctors assess and manage your medical treatment. Nurses provide ongoing care. Allied health professionals provide services to help with diagnosis and treatment, and help you during the recovery process. Support and administrative staff work to support the day-to-day running of the hospital.',
        price:'$100'
    },
    {
        title:'Supporting Live care',
        image:'https://images.pexels.com/photos/6782567/pexels-photo-6782567.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
        description:'Hotels are typically larger establishments that offer a range of amenities and facilities, such as restaurants, bars, conference rooms, and fitness centres. They often have multiple room options, including single rooms, double rooms, suites, and family rooms.',
        price:'$100'
    },
    
]

 export const Data1=[
    {
        title:'Live care',
        image:'https://media.istockphoto.com/id/1134451603/photo/she-knows-just-how-to-make-each-patient-feel-special.jpg?s=2048x2048&w=is&k=20&c=F1D3KYiQ0ZGEsVwN-6HKuviE5o-0bZA4j0T6LIrFIgM=',
        description:'Wellness hotels have been around for a while, but are now becoming a focal point for both business and leisure travelers. With good reason! Not only are wellness hotels often more in-tune with nature, but they’re also soothing for the mind, body, and soul.',
        price:'$100'
        
    },
    {
        title:'Surpportin live care',
        image:'https://images.pexels.com/photos/6782567/pexels-photo-6782567.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
        description:'Hotels are typically larger establishments that offer a range of amenities and facilities, such as restaurants, bars, conference rooms, and fitness centres. They often have multiple room options, including single rooms, double rooms, suites, and family rooms.',
        price:'$100'
    },
    {
        title:'Staffs to NHS Hospitals ',
        image:'https://images.pexels.com/photos/8442574/pexels-photo-8442574.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
        description:'Doctors assess and manage your medical treatment. Nurses provide ongoing care. Allied health professionals provide services to help with diagnosis and treatment, and help you during the recovery process. Support and administrative staff work to support the day-to-day running of the hospital.',
        price:'$100'
    },
    {
        title:'Supporting Live care',
        image:'https://images.pexels.com/photos/6782567/pexels-photo-6782567.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
        description:'Hotels are typically larger establishments that offer a range of amenities and facilities, such as restaurants, bars, conference rooms, and fitness centres. They often have multiple room options, including single rooms, double rooms, suites, and family rooms.',
        price:'$100'
    },
]